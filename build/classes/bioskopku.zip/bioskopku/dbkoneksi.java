package bioskopku;
import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author Endang Siti W
 */
public class dbkoneksi {
    public static Connection conn;
    public static java.sql.Statement st;
    public static Connection koneksi;
        public static Connection getConnection() throws SQLException {
        if (koneksi == null) {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection("jdbc:mysql://localhost:3306/bioskopku", "root", "");
            } catch (ClassNotFoundException ex) {
                System.err.println("MySQL Connector/J driver not found");
            }
        }
        return koneksi;
    }
    public static void main(String[]args){
        try{
            getConnection();
            JOptionPane.showMessageDialog(null,"koneksi berhasil","report koneksi",JOptionPane.INFORMATION_MESSAGE);
        }
        catch (SQLException ex){
            System.err.println();
        }
    }
}